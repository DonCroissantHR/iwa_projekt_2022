</section>
<footer>
  <p>
    <a style="color: blue" href="mailto:pkrajacic@student.foi.hr">
      pkrajacic@student.foi.hr
    </a>
    <br>
    &copy; 2023 Petar Krajačić
  </p>
</footer>
</body>
</html>
